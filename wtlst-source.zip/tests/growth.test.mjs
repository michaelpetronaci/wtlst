import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {weeklyReport} from '../growth.mjs';
import {emailPayload,deliver} from '../email.mjs';
const {PGlite}=await import('@electric-sql/pglite').catch(()=>import('../.work/dbtest/node_modules/@electric-sql/pglite/dist/index.js'));
test('Growth: attribution, private admin aggregation, reminder eligibility/cancellation/once, weekly idempotency',async()=>{
 const db=new PGlite();
 try{
 await db.exec(`create role anon;create role authenticated;create role service_role;create schema auth;create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;`);
 await db.exec(await readFile('WTLST_SETUP.sql','utf8'));const migration=await readFile('GROWTH_SETUP.sql','utf8');await db.exec(migration);await db.exec(migration);
 const ids=[1,2,3,4,5].map(n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`);
 for(const id of ids)await db.query('insert into auth.users values($1,$2,now())',[id,'private@example.com']);
 const as=async(role,id,q,args=[])=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id||'']);await db.exec(`set role ${role}`);return db.query(q,args);};
 const rpc=async(role,id,name,args=[])=>{const r=await as(role,id,`select public.${name}(${args.map((_,i)=>'$'+(i+1)).join(',')}) result`,args);return r.rows[0].result;};
 const apply=(id,ref=null,inv=null)=>rpc('authenticated',id,'wtlst_apply',['Private name','Private city','','Private reason for application',ref,inv]);
 const a=await apply(ids[0]);await apply(ids[1],a.application.referral_code);
 await as('postgres',null,'insert into private.admins values($1)',[ids[0]]);
 await rpc('authenticated',ids[0],'wtlst_admit',[a.application.id]);const owner=await rpc('authenticated',ids[0],'wtlst_me');
 await apply(ids[2],null,owner.application.invite_code);
 const second=await rpc('authenticated',ids[2],'wtlst_me');
 const waiting=await apply(ids[3]);await rpc('authenticated',ids[3],'wtlst_redeem',[second.application.invite_code]);
 await assert.rejects(rpc('anon',null,'wtlst_admin_growth'));
 await assert.rejects(rpc('authenticated',ids[1],'wtlst_admin_growth'));
 await assert.rejects(rpc('authenticated',ids[0],'wtlst_growth_schedule'));
 await assert.rejects(as('authenticated',ids[0],'select * from private.growth_applications'));
 const g=await rpc('authenticated',ids[0],'wtlst_admin_growth');
 assert.equal(g.snapshot.applications,4);assert.equal(g.snapshot.direct,2);assert.equal(g.snapshot.referral,1);assert.equal(g.snapshot.invitation,1);assert.equal(g.snapshot.invitation_admissions,2);assert.equal(g.snapshot.manual_admissions,1);
 assert.equal(g.snapshot.verified_referrals,1);assert.equal(g.snapshot.referrers,1);assert.equal(g.top_referrers[0].id,a.application.id);
 assert.equal(JSON.stringify(g).includes('Private'),false);assert.equal(JSON.stringify(g).includes('private@example.com'),false);
 await as('postgres',null,"select private.growth_schedule(now())");
 let rows=(await as('postgres',null,"select * from private.outbox where kind='invitation_reminder'")).rows;assert.equal(rows.length,0);
 await as('postgres',null,"update private.applications set admitted_at=now()-interval '11 days' where status='admitted'");
 await rpc('service_role',null,'wtlst_growth_schedule');await rpc('service_role',null,'wtlst_growth_schedule');
 rows=(await as('postgres',null,"select * from private.outbox where kind='invitation_reminder'")).rows;assert.equal(rows.length,1);assert.equal(rows[0].applicant_id,waiting.application.id);
 await as('postgres',null,"update private.outbox set sent_at=now() where kind<>'invitation_reminder'");
 const jobs=await rpc('service_role',null,'wtlst_email_claim');assert.equal(jobs.length,1);
 // An invitation redeemed after the job was claimed must cancel the prepared send.
 const w=await rpc('authenticated',ids[3],'wtlst_me');await apply(ids[4],null,w.application.invite_code);
 assert.equal(await rpc('service_role',null,'wtlst_email_prepare',[jobs[0].id,jobs[0].lease,{subject:'Do not send'}]),null);
 assert.equal((await rpc('service_role',null,'wtlst_email_claim')).length,3); // application/operator/admission jobs only
 // New member: threshold, actual reminder, then no second reminder even on repeated cron.
 await as('postgres',null,"update private.applications set admitted_at=now()-interval '10 days' where user_id=$1",[ids[4]]);
 await rpc('service_role',null,'wtlst_growth_schedule');
 const reminder=(await rpc('service_role',null,'wtlst_email_claim')).find(j=>j.kind==='invitation_reminder');assert.ok(reminder);
 await rpc('service_role',null,'wtlst_email_prepare',[reminder.id,reminder.lease,{subject:'Once'}]);await rpc('service_role',null,'wtlst_email_finish',[reminder.id,reminder.lease,'receipt',null]);
 await rpc('service_role',null,'wtlst_growth_schedule');assert.equal((await rpc('service_role',null,'wtlst_email_claim')).filter(j=>j.kind==='invitation_reminder').length,0);
 // Monday queue twice: exactly one report for that week; no fake applicant.
 await as('postgres',null,"select private.growth_schedule('2030-01-07 07:00:00Z')");await as('postgres',null,"select private.growth_schedule('2030-01-07 07:30:00Z')");
 const reports=(await as('postgres',null,"select * from private.outbox where dedupe_key='weekly-growth:2030-01-07'")).rows;
 assert.equal(reports.length,1);assert.equal(reports[0].applicant_id,null);assert.equal(Object.hasOwn(reports[0].context,'top_referrers'),false);
 assert.match(weeklyReport(reports[0].context),/Suggested founder action:/);
 await as('postgres',null,'update auth.users set email_confirmed_at=null where id=$1',[ids[0]]);await assert.rejects(rpc('authenticated',ids[0],'wtlst_admin_growth'));
 }finally{await db.close();}
});
const env={SUPABASE_URL:'https://test.supabase.co',SUPABASE_ANON_KEY:'sb_publishable_test',SUPABASE_SECRET_KEY:'sb_secret_test',RESEND_API_KEY:'test',PRIVACY_CONTACT:'operator@example.com',SITE_URL:'https://www.thewtlst.com'};
test('Reminder and report emails use canonical sender, no private report data, deterministic suggestions',()=>{
 const p=emailPayload({kind:'invitation_reminder',member_number:3,email:'member@example.com'},env);
 assert.equal(p.subject,'Your invitation remains.');assert.equal(p.from,'WTLST <noreply@thewtlst.com>');assert.match(p.text,/MEMBER 000003/);assert.match(p.text,/https:\/\/www.thewtlst.com\/\?view=login/);
 const g={as_of:'2026-09-21',snapshot:{members:5,waiting:10,invitations:5,redeemed:0,unused:5},periods:{last7:{applications:12,members:2,waiting_change:10,direct:10,referral:1,invitation:1,invitation_admissions:1},previous7:{applications:10}}};
 const r=emailPayload({kind:'weekly_growth',context:g},env);assert.deepEqual(r.to,['operator@example.com']);assert.match(r.text,/Personally contact 3 members/);assert.match(r.text,/increased 20%/);assert.match(r.text,/Strongest acquisition source: direct/);
});
test('Delivery skips cancelled reminder, schedules only cron, keeps idempotency key and frozen payload',async()=>{
 const calls=[];let claims=0;
 const fetcher=async(url,options)=>{const name=url.split('/').at(-1);calls.push(name);let data;
 if(name==='wtlst_growth_schedule')data={};
 else if(name==='wtlst_email_claim')data=claims++?[]:[{id:'one',lease:'lease',kind:'invitation_reminder',email:'member@example.com',member_number:1},{id:'two',lease:'lease',payload:{from:'WTLST <noreply@thewtlst.com>',to:['operator@example.com'],subject:'Frozen',text:'Fixed'}}];
 else if(name==='wtlst_email_prepare')data=JSON.parse(options.body).p_id==='one'?null:JSON.parse(options.body).p_payload;
 else if(name==='emails'){assert.equal(options.headers['Idempotency-Key'],'wtlst-two');assert.equal(JSON.parse(options.body).subject,'Frozen');data={id:'receipt'};}
 else data=null;
 return new Response(JSON.stringify(data),{status:200});};
 const result=await deliver({cron:true,env,fetcher});assert.equal(result.body.sent,1);assert.equal(result.body.skipped,1);assert.equal(calls.filter(n=>n==='emails').length,1);assert.equal(calls[0],'wtlst_growth_schedule');
});
