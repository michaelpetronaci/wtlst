# WTLST implementation

- Portable browser app with Supabase Auth email OTP (Resend SMTP).
- Form details stay in session storage until verification; only verified users enter the queue.
- Postgres functions perform applications, rank calculation, admissions, and one-use invitations atomically.
- Queue score = application sequence minus five times verified referrals. Ties resolve by sequence. Only waiting applicants are ranked; position is computed live.
- Member number is assigned once by database sequence under row lock.
- Invitations are opaque, single-use links. Redemption on verified application admits invitee atomically; existing waiting applicants can redeem too. Members cannot consume another invitation.
- Minimal admin uses the same email OTP; database allowlist grants privileges, never user-editable metadata.
- Admission inserts a transactional email into an outbox in the same transaction. A Supabase Edge Function sends through Resend using idempotency keys; manual retry in admin plus scheduled retry on Supabase. No separate queue service.
- No browser service-role credentials. RLS blocks direct private-table access. Narrow RPCs validate auth and return only caller-owned records, public counts, or explicitly published membership cards.
- Public member cards expose member number by default; name/city publication is opt-in.
- Missing backend configuration disables application submission clearly; no fake data or simulated success.
