import {useEffect,useState} from 'react';
import {rpc} from '../lib/supabase';
type Stats=Record<string,number|null>;
type Growth={as_of:string;snapshot:Stats;periods:Record<string,Stats>;top_referrers:{id:number;member_number:number|null;referrals:number;admitted:number}[]};
const pct=(n:number|null|undefined,d:number|null|undefined)=>d?`${(100*(n||0)/d).toFixed(1)}%`:'—';
export function GrowthDashboard(){
 const [g,setG]=useState<Growth|null>(null),[error,setError]=useState('');
 async function load(){setError('');try{setG(await rpc<Growth>('wtlst_admin_growth'));}catch(e){setError(e instanceof Error?e.message:'Unable to load growth.');}}
 useEffect(()=>{void load();},[]);
 const s=g?.snapshot;
 return <section className="growth-section" aria-label="Growth"><div className="admin-tools"><h2>Growth.</h2><button className="text-button" onClick={()=>void load()}>Refresh growth</button></div>{error&&<p role="alert">{error}</p>}{!s||!g?<p>Loading growth…</p>:<>
 <div className="growth-grid">{[['Applications',s.applications],['Waiting',s.waiting],['Members',s.members],['Applications / 7 days',g.periods.last7.applications],['New members / 7 days',g.periods.last7.members]].map(([label,n])=><div className="growth-stat" key={String(label)}><span>{label}</span><strong>{n??'—'}</strong></div>)}</div>
 <h3>Acquisition</h3><div className="growth-grid">{[['Direct',s.direct],['Referral',s.referral],['Invitation applications',s.invitation],['Manual admissions',s.manual_admissions],['Invitation admissions',s.invitation_admissions],['Applications from referrals',pct(s.referral,s.applications)],['Members through invitations',pct(s.invitation_admissions,s.members)]].map(([l,n])=><div className="growth-stat" key={String(l)}><span>{l}</span><strong>{n??'—'}</strong></div>)}</div>
 <h3>Invitation loop</h3><div className="growth-grid">{[['Invitations generated',s.invitations],['Unused',s.unused],['Redeemed',s.redeemed],['Redemption rate',pct(s.redeemed,s.invitations)],['Median days to use',s.redemption_median_days?.toFixed(1)],['Average days to use',s.redemption_avg_days?.toFixed(1)]].map(([l,n])=><div className="growth-stat" key={String(l)}><span>{l}</span><strong>{n??'—'}</strong></div>)}</div>
 <h3>Referral loop</h3><p>{s.verified_referrals} verified referrals · {s.referrers} applicants with ≥1 referral · {pct(s.referred_members,s.verified_referrals)} of referred applicants admitted</p>
 <div className="growth-table"><table><caption>Growth periods — rolling days</caption><thead><tr><th>Period</th><th>Applications</th><th>Members</th><th>Direct</th><th>Referral</th><th>Invite admissions</th></tr></thead><tbody>{[['last7','Last 7 days'],['previous7','Previous 7 days'],['last30','Last 30 days']].map(([key,label])=><tr key={key}><th>{label}</th>{['applications','members','direct','referral','invitation_admissions'].map(k=><td key={k}>{g.periods[key][k]}</td>)}</tr>)}</tbody></table></div>
 <h3>Top referrers</h3>{g.top_referrers.length?<ol>{g.top_referrers.map(r=><li key={r.id}>{r.member_number?`Member ${String(r.member_number).padStart(6,'0')}`:`Application #${r.id}`} — {r.referrals} referrals, {r.admitted} admitted</li>)}</ol>:<p>No verified referrals yet.</p>}
 <p className="fine">Verified database activity only. No visitor identifiers, cookies, IP addresses or click tracking. Visitor-to-application and link-click conversion are not measured. Historical totals reflect retained accounts; deletion can change them. Invitation applications are those submitted while redeeming an invite; later redemption preserves the original source. These are descriptive counts, not statistical conclusions.</p>
 </>}</section>;
}
