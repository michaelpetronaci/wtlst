'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { getClient, rpc, deliverEmails } from '../lib/supabase';

type Application = { id:number; name:string; city:string; social:string; reason:string; status:string; position:number|null; referral_code:string; referrals:number; member_number:number|null; admitted_at:string|null; invite_code:string|null; invite_used:boolean; public_profile:boolean; email?:string };
type Me = { application:Application|null; admin:boolean };
type Member = Pick<Application,'name'|'city'|'member_number'|'admitted_at'>;
const number = (n:number|null|undefined) => n == null ? '—' : String(n).padStart(6,'0');
const uuid = (s:string|null) => s && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s) ? s : null;

export default function Wtlst() {
  const [view,setView] = useState('home');
  const [ready,setReady] = useState<boolean|null>(null);
  const [counts,setCounts] = useState<{waiting:number;admitted:number}|null>(null);
  const [me,setMe] = useState<Me|null>(null);
  const [email,setEmail] = useState('');
  const [otp,setOtp] = useState('');
  const [sent,setSent] = useState(false);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [notice,setNotice] = useState('');
  const [draft,setDraft] = useState({name:'',city:'',social:'',reason:''});
  const [ref,setRef] = useState<string|null>(null);
  const [invite,setInvite] = useState<string|null>(null);
  const [memberLoading,setMemberLoading] = useState(false);
  const [member,setMember] = useState<Member|null>(null);
  const [admin,setAdmin] = useState<{applications:Application[];pending_emails:number;total:number}|null>(null);
  const [offset,setOffset] = useState(0);
  const [contact,setContact] = useState('');
  const [operator,setOperator] = useState('');
  function go(next:string) { setView(next);setSent(false);setOtp('');setError('');setNotice(''); window.history.pushState({},'',next==='home'?'/':`/?view=${next}`);window.scrollTo(0,0); }
  async function run(action:()=>Promise<void>) {setBusy(true);setError('');setNotice('');try{await action();}catch(e){setError(e instanceof Error?e.message:'Something went wrong. Please try again.');}finally{setBusy(false);}}
  async function refresh() {const result=await rpc<Me>('wtlst_me');setMe(result);setCounts(await rpc('wtlst_counts'));return result;}
  async function emails() {try{await deliverEmails();}catch(e){setNotice(e instanceof Error?e.message:'Email delivery pending.');}}
  useEffect(()=>{
    const query=new URLSearchParams(window.location.search);
    const validViews=['home','apply','login','status','admin','privacy'];
    const readView=()=>{const q=new URLSearchParams(window.location.search);return q.has('member')?'public':q.has('ref')||q.has('invite')?'apply':validViews.includes(q.get('view')||'')?q.get('view')!:'home';};
    setView(readView());
    for(const kind of ['ref','invite']){const value=uuid(query.get(kind));if(value)sessionStorage.setItem('wtlst-'+kind,value);}
    setRef(uuid(sessionStorage.getItem('wtlst-ref')));setInvite(uuid(sessionStorage.getItem('wtlst-invite')));
    setMemberLoading(query.has('member'));
    if(query.has('ref')||query.has('invite'))setView('apply');
    const saved=sessionStorage.getItem('wtlst-draft');if(saved){try{setDraft(JSON.parse(saved));}catch{sessionStorage.removeItem('wtlst-draft');}}
    const pop=()=>{setView(readView());setSent(false);setOtp('');setError('');};window.addEventListener('popstate',pop);
    void (async()=>{try{
      const cfg=await fetch('/api/config').then(r=>r.json());setContact(cfg.privacyContact||'');setOperator(cfg.operator||'');
      const db=await getClient();setReady(!!db);if(!db)return;
      setCounts(await rpc('wtlst_counts'));
      if(query.has('member')){setView('public');setMember(await rpc('wtlst_member',{p_number:Number(query.get('member'))}));setMemberLoading(false);}
      const {data}=await db.auth.getSession();if(data.session){setEmail(data.session.user.email||'');await refresh();void emails();}
    }catch(e){setError(e instanceof Error?e.message:'Unable to connect.');setReady(false);setMemberLoading(false);}})();
    return()=>window.removeEventListener('popstate',pop);
  },[]);
  async function requestCode(e:FormEvent) {e.preventDefault();await run(async()=>{
    const db=await getClient();if(!db)throw new Error('Applications are not open yet. Please check back soon.');
    if(view==='apply'){sessionStorage.setItem('wtlst-draft',JSON.stringify(draft));}
    const {error}=await db.auth.signInWithOtp({email:email.trim(),options:{shouldCreateUser:view==='apply'}});if(error)throw error;setSent(true);setNotice('Check your inbox for your sign-in code.');
  });}
  async function verify(e:FormEvent){e.preventDefault();await run(async()=>{
    const db=await getClient();if(!db)throw new Error('Connection unavailable.');
    const {error}=await db.auth.verifyOtp({email:email.trim(),token:otp,type:'email'});if(error)throw error;
    const result=await refresh();setSent(false);setOtp('');
    if(view==='apply'&&!result.application){await submit();}else{go(view==='admin'?'admin':'status');}
  });}
  async function submit(){const result=await rpc<Me>('wtlst_apply',{p_name:draft.name,p_city:draft.city,p_social:draft.social,p_reason:draft.reason,p_ref:ref,p_invite:invite});setMe(result);sessionStorage.removeItem('wtlst-draft');sessionStorage.removeItem('wtlst-ref');sessionStorage.removeItem('wtlst-invite');go('status');await emails();}
  async function loadAdmin(n=offset){setAdmin(await rpc('wtlst_admin_list',{p_offset:n}));setOffset(n);}
  useEffect(()=>{if(view==='admin'&&me?.admin)void run(()=>loadAdmin(0));},[view,me?.admin]);
  async function copy(value:string){await run(async()=>{await navigator.clipboard.writeText(value);setNotice('Link copied.');});}
  const a=me?.application;
  const origin=typeof window==='undefined'?'':window.location.origin;
  const link=(key:string,value:string|number)=>`${origin}/?${key}=${value}`;
  function card(m:Member,own=false){return <div className="member-card"><div className="card-top"><strong>WTLST</strong><span>MEMBER</span></div><div className="card-number">{number(m.member_number)}</div><div className="card-bottom"><div>{m.name&&<strong>{m.name}</strong>}{m.city&&<span>{m.city}</span>}</div><div><span>ADMITTED</span><strong>{m.admitted_at?new Date(m.admitted_at).toLocaleDateString('en-GB'):''}</strong></div></div><div className="card-rule"/><p>{own?'You’re in. Don’t make this embarrassing.':'One of the few.'}</p></div>;}
  return <div className="shell"><header><a className="wordmark" href="/" onClick={e=>{e.preventDefault();go('home');}}>WTLST</a><nav><button onClick={()=>go(a?'status':'login')}>{a?'Your membership':'Check your status'}</button>{me?.admin&&<button onClick={()=>go('admin')}>Admin</button>}</nav></header>
    <main>
      {error&&<div className="message error" role="alert">{error}</div>}{notice&&<div className="message" role="status">{notice}</div>}
      {view==='home'&&<section className="hero"><p className="eyebrow">THE WAITLIST / OPEN WORLDWIDE</p><h1>You probably<br/>won’t get in<span className="accent">.</span></h1><div className="hero-bottom"><div className="counts"><div><strong>{counts?counts.waiting.toLocaleString():'—'}</strong><span>waiting</span></div><div><strong>{counts?counts.admitted.toLocaleString():'—'}</strong><span>admitted</span></div></div><div className="apply-block"><Button className="action" onClick={()=>go(a?'status':'apply')}>{a?'YOUR STATUS':'APPLY'}<span aria-hidden>↗</span></Button><p>Getting on the list is the easy part.</p></div></div><div className="hero-foot"><span>FREE MEMBERSHIP. NO GUARANTEE.</span><span>ADMISSIONS AT OUR DISCRETION.</span></div></section>}
      {(view==='apply'||view==='login'||(view==='admin'&&!me))&&<section className="form-layout"><div><p className="eyebrow">{view==='apply'?'01 / THE APPLICATION':'YOUR PRIVATE ACCESS'}</p><h1 className="small-title">{sent?'Check your\ninbox.':view==='apply'?'Make your\ncase.':'Still\nwaiting?'}</h1><p className="muted">{sent?'Enter the code we sent you.':view==='apply'?'A place on the list costs nothing. Admission is another matter.':'Use the email you applied with to see your position or membership.'}</p>{invite&&<p className="invitation-note">You have an invitation. Verify your email to claim it. First redemption wins. <button className="inline-link" type="button" onClick={()=>{setInvite(null);sessionStorage.removeItem('wtlst-invite');}}>Apply without this invitation</button></p>}</div><div className="form-panel">
        {ready===false?<div className="unavailable"><h2>Not open just yet.</h2><p>Applications will open here soon. Please check back.</p></div>:sent?<form onSubmit={verify}><label htmlFor="code">Code sent to {email}</label><InputOTP id="code" maxLength={6} value={otp} onChange={setOtp} pattern="[0-9]*" aria-label="Email verification code"><InputOTPGroup>{[0,1,2,3,4,5].map(i=><InputOTPSlot className="otp-slot" key={i} index={i}/>)}</InputOTPGroup></InputOTP><Button className="action" type="submit" disabled={busy||otp.length!==6}>{busy?'VERIFYING…':'VERIFY EMAIL'}</Button><button className="text-button" type="button" onClick={()=>{setSent(false);setOtp('');}}>Change email or request another code</button></form>:<form onSubmit={e=>{if(me&&view==='apply'){e.preventDefault();void run(submit);}else void requestCode(e);}}>
          {view==='apply'&&<><label htmlFor="name">First name<Input id="name" required maxLength={60} autoComplete="given-name" value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/></label><label htmlFor="city">City<Input id="city" required maxLength={80} autoComplete="address-level2" value={draft.city} onChange={e=>setDraft({...draft,city:e.target.value})}/></label><label htmlFor="social">Social handle <span className="muted">(optional)</span><Input id="social" maxLength={100} placeholder="@you" value={draft.social} onChange={e=>setDraft({...draft,social:e.target.value})}/></label></>}
          <label htmlFor="email">Email<Input id="email" required type="email" autoComplete="email" value={email} disabled={!!me} onChange={e=>setEmail(e.target.value)}/></label>
          {view==='apply'&&<label htmlFor="reason">Why should we let you in?<Textarea id="reason" required minLength={10} maxLength={1000} rows={4} value={draft.reason} onChange={e=>setDraft({...draft,reason:e.target.value})}/></label>}
          <p className="fine">{view==='apply'?'We’ll email you a verification code and updates about your application. No marketing list. ':''}<button type="button" className="inline-link" onClick={()=>go('privacy')}>Privacy</button></p>
          <Button className="action" type="submit" disabled={busy||ready!==true}>{busy?'ONE MOMENT…':me?'SUBMIT APPLICATION':'SEND VERIFICATION CODE'}</Button>
        </form>}
      </div></section>}
      {view==='status'&&<section className="status-page">{!me?<><h1 className="small-title">Your place<br/>is private.</h1><Button className="action" onClick={()=>go('login')}>SIGN IN</Button></>:!a?<><h1 className="small-title">You’re verified.</h1><p>Now make your case.</p><Button className="action" onClick={()=>go('apply')}>COMPLETE APPLICATION</Button></>:a.status==='waiting'?<><p className="eyebrow">APPLICATION RECEIVED / {a.name.toUpperCase()}</p><h1 className="small-title">You’re on<br/>the list.</h1><div className="position"><span>YOUR CURRENT POSITION</span><strong>#{a.position?.toLocaleString()}</strong></div><div className="status-grid"><div><h2>Good company helps.</h2><p>Each verified referral improves your ranking score by five. Your position is live and also depends on other applicants and admissions.</p><label htmlFor="referral">Your referral link</label><div className="copy-row"><Input id="referral" readOnly value={link('ref',a.referral_code)}/><Button onClick={()=>copy(link('ref',a.referral_code))}>Copy</Button></div><p className="fine">{a.referrals} verified {a.referrals===1?'referral':'referrals'}. Admission is not guaranteed.</p></div><div className="aside"><p>Being patient is optional.<br/>Being admitted is not up to you.</p><button className="text-button" disabled={busy} onClick={()=>run(async()=>{await refresh();setNotice('Position updated.');})}>Refresh position</button></div></div>{invite&&<Button className="action" disabled={busy} onClick={()=>run(async()=>{setMe(await rpc('wtlst_redeem',{p_invite:invite}));setInvite(null);await emails();})}>REDEEM YOUR INVITATION</Button>}</>:<><p className="eyebrow">ADMISSION CONFIRMED</p><h1 className="small-title">You’re in.</h1>{card(a,true)}<div className="status-grid"><div><h2>{a.invite_used?'Your invitation is spoken for.':'One invitation. Choose well.'}</h2>{!a.invite_used&&a.invite_code&&<><p>This link admits one person after email verification. Anyone with it can claim it.</p><div className="copy-row"><Input aria-label="Your invitation link" readOnly value={link('invite',a.invite_code)}/><Button onClick={()=>copy(link('invite',a.invite_code!))}>Copy</Button></div></>}<Button className="secondary" onClick={()=>copy(link('member',a.member_number!))}>Copy public member page</Button></div><div className="aside"><h2>Your public card</h2><p>By default, only your member number and admission date are public.</p><Button className="secondary" disabled={busy} onClick={()=>run(async()=>{await rpc('wtlst_profile',{p_public:!a.public_profile});await refresh();})}>{a.public_profile?'Hide name and city':'Publish name and city'}</Button></div></div></>}{me&&<button className="text-button" onClick={()=>run(async()=>{await (await getClient())?.auth.signOut();setMe(null);go('home');})}>Sign out</button>}</section>}
      {view==='public'&&<section className="status-page"><p className="eyebrow">THE MEMBERSHIP REGISTER</p>{memberLoading?<p>Loading membership…</p>:member?<><h1 className="small-title">One of<br/>the few.</h1>{card(member)}<Button className="action" onClick={()=>go('apply')}>GET ON THE LIST</Button></>:<><h1 className="small-title">No member<br/>found.</h1><p>Check the link and try again.</p></>}</section>}
      {view==='admin'&&me&&<section className="admin-page"><p className="eyebrow">WTLST / ADMIN</p><h1 className="small-title">Admissions.</h1>{!me.admin?<p>This account does not have admin access.</p>:<><div className="admin-tools"><span>{admin?.total??'—'} applications · {admin?.pending_emails??'—'} emails pending</span><Button disabled={busy} onClick={()=>run(async()=>{await emails();await loadAdmin();})}>Retry pending emails</Button></div>{admin?.applications.map(item=><article className="application" key={item.id}><div><p className="eyebrow">#{item.id} · {item.status} · {item.referrals} referrals</p><h2>{item.name} <span className="muted">/ {item.city}</span></h2><p className="fine">{item.email} {item.social&&`· ${item.social}`}</p><p className="reason">{item.reason}</p></div><Button disabled={busy||item.status==='admitted'} onClick={()=>run(async()=>{await rpc('wtlst_admit',{p_id:item.id});await emails();await loadAdmin();})}>{item.status==='admitted'?`MEMBER ${number(item.member_number)}`:'Admit'}</Button></article>)}{admin?.applications.length===0&&<p>No applications yet.</p>}<div className="admin-tools"><Button disabled={busy||offset===0} onClick={()=>run(()=>loadAdmin(Math.max(0,offset-50)))}>Previous</Button><Button disabled={busy||!admin||offset+50>=admin.total} onClick={()=>run(()=>loadAdmin(offset+50))}>Next</Button></div></>}</section>}
      {view==='privacy'&&<section className="privacy"><p className="eyebrow">WTLST / PRIVACY</p><h1 className="small-title">Your details.</h1><p>We use your email, application answers, referral activity and membership status to operate WTLST, verify your identity, rank the list and send application and admission emails.</p><p>Your email and application answers are private. Member numbers and admission dates can be viewed on public member pages. Publishing your first name and city is optional.</p><p>Supabase stores application and authentication data. Resend delivers transactional emails. Your browser stores your sign-in session and unfinished application. We do not use advertising trackers.</p><p>Applications are kept while this membership experiment is operating or until you request deletion. Referral counts can change when accounts are removed.</p><p>{operator?`Operated by ${operator}. `:''}{contact?<>For access, correction or deletion requests: <a href={`mailto:${contact}`}>{contact}</a>.</>:'Contact details will be published before applications open.'}</p><button className="text-button" onClick={()=>go('apply')}>Back to application</button></section>}
    </main><footer><span>WTLST / THE WAITLIST</span><button onClick={()=>go('privacy')}>Privacy</button><span>FREE TO APPLY. FREE TO BELONG.</span></footer>
  </div>;
}
