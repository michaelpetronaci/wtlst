export async function GET() {
  return Response.json({
    url: process.env.SUPABASE_URL || '',
    key: process.env.SUPABASE_ANON_KEY || '',
    privacyContact: process.env.PRIVACY_CONTACT || '',
    operator: process.env.SITE_OPERATOR || '',
  }, { headers: { 'Cache-Control': 'no-store' } });
}
