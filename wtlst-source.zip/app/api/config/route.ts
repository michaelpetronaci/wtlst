import {publicConfig} from '../../../../config.mjs';
export async function GET(){try{return Response.json(publicConfig(),{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'Service temporarily unavailable'},{status:503});}}
