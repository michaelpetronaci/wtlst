import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'WTLST — You probably won’t get in.',
  description: 'One list. A few admissions. Apply to WTLST. Membership is free.',
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
