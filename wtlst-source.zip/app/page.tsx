import Wtlst from '../components/wtlst';
export default function Page() { return <Wtlst />; }
