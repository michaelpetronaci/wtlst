// Deploy with JWT verification disabled at gateway: this function validates JWTs
// itself through Supabase Auth, including projects using asymmetric JWT signing.
const env = (key: string) => { const value = Deno.env.get(key); if (!value) throw new Error(`Missing ${key}`); return value; };
const json = (value: unknown, status=200) => new Response(JSON.stringify(value), {status,headers:{'Content-Type':'application/json',...cors}});
const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS'};
Deno.serve(async(request: Request) => {
 if(request.method==='OPTIONS')return new Response(null,{headers:cors});
 if(request.method!=='POST')return json({error:'Method not allowed'},405);
 try {
  const url=env('SUPABASE_URL'), service=env('SUPABASE_SERVICE_ROLE_KEY');
  const auth=request.headers.get('Authorization')||'';
  const call=async(name:string,args:unknown,key=service,bearer=service)=>{
   const response=await fetch(`${url}/rest/v1/rpc/${name}`,{method:'POST',headers:{apikey:key,Authorization:`Bearer ${bearer}`,'Content-Type':'application/json'},body:JSON.stringify(args)});
   if(!response.ok)throw new Error(`Database operation failed (${response.status})`);
   return response.status===204?null:response.json();
  };
  let applicant:number|null=null;
  const cron=Deno.env.get('WTLST_CRON_SECRET');
  if(!cron||auth!==`Bearer ${cron}`){
   const token=auth.replace(/^Bearer /,'');if(!token)return json({error:'Sign in required'},401);
   const user=await fetch(`${url}/auth/v1/user`,{headers:{apikey:service,Authorization:auth}});
   if(!user.ok)return json({error:'Sign in required'},401);
   const me=await call('wtlst_me',{},service,token);
   if(!me.admin){if(!me.application)return json({sent:0});applicant=me.application.id;}
  }
  const site=env('SITE_URL').replace(/\/$/,'');
  const from=env('EMAIL_FROM');
  const key=env('RESEND_API_KEY');
  const jobs=await call('wtlst_claim_emails',{p_applicant:applicant});
  let sent=0,failed=0;
  for(const job of jobs){
   const member=String(job.member_number||'').padStart(6,'0');
   const admission=job.kind==='admission';
   const subject=admission?`You’re in. WTLST MEMBER ${member}`:'You’re on the WTLST.';
   const text=admission?`You’re in.\n\nMEMBER ${member}\n\nOne invitation available. Choose well.\n\nView your membership: ${site}/?view=login\n\nWTLST membership is free.`:`Your application is in.\n\nView your live position and get your referral link: ${site}/?view=login\n\nEvery verified referral improves your ranking score. Admission is not guaranteed.\n\nWTLST membership is free.`;
   try{
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','Idempotency-Key':`wtlst-${job.id}`},body:JSON.stringify({from,to:[job.email],subject,text})});
    if(!response.ok){failed++;await call('wtlst_finish_email',{p_id:job.id,p_error:`Email provider returned ${response.status}`});}
    else{await call('wtlst_finish_email',{p_id:job.id,p_error:null});sent++;}
   }catch{failed++;await call('wtlst_finish_email',{p_id:job.id,p_error:'Delivery interrupted. Retry pending.'});}
  }
  return json({sent,failed},failed?502:200);
 }catch{ return json({error:'Email delivery unavailable. Saved changes are unaffected.'},503); }
});
