-- Replace the placeholder with the owner's verified WTLST sign-in email.
-- Run only in this project's SQL editor after the owner signs into the app.
insert into private.admins(user_id)
select id from auth.users where lower(email)=lower('REPLACE_WITH_OWNER_EMAIL')
and email_confirmed_at is not null
on conflict do nothing;
