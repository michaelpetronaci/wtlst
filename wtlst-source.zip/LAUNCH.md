# WTLST launch status

The app is being implemented. It is not ready for public launch until the checks below pass.

## Accounts created / scoped
- Private GitHub repository: https://github.com/michaelpetronaci/wtlst
- Supabase organization: WTLST (Free); project creation awaiting owner password step.
- Resend sending domain: thewtlst.com, under the existing team. A separate team requires payment.
- GoDaddy: only thewtlst.com is authorized. No other domains may be changed.
- Email DNS added: resend._domainkey TXT, send TXT, send MX (Ireland endpoint).

## Required configuration
1. Apply supabase/migrations/001_wtlst.sql once in the new project.
2. Configure Supabase Auth custom SMTP with Resend; use hello@thewtlst.com as sender. Set the auth email template to display {{ .Token }} and set code length to 6. Site URL must match deployed origin. Enable email confirmations, disable unused auth providers, configure resend cooldown/rate limits.
3. Deploy supabase/functions/send-emails. Set secrets RESEND_API_KEY, EMAIL_FROM, SITE_URL, WTLST_CRON_SECRET. Use a sending-only Resend key restricted to thewtlst.com. Never expose the key to browser code.
4. Configure scheduled calls to the email function (every five minutes) using Supabase Cron and Vault for the secret. Browser-triggered sends are immediate; scheduled retries recover provider interruptions.
5. Set app SUPABASE_URL, SUPABASE_ANON_KEY, SITE_OPERATOR, PRIVACY_CONTACT.
6. Owner signs into the app, then run setup-admin.sql with their verified email.
7. Test real OTP delivery, application, duplicate application, referral movement, admin access denial, admission, member card, single-use invitation, and retryable email delivery.
8. Deploy the validated app to approved hosting, then attach thewtlst.com and www. Confirm HTTPS and repeat the live flow.

## Product rules
Verified identities only enter the list. Ranking score is application sequence minus five per verified referral, with application sequence breaking ties. Displayed position is a live rank among waiting applicants. Members receive one single-use invitation. Public member pages show only number/date until a member opts into publishing name/city.

## Costs and operations
No payment processor, analytics SaaS, CMS, or marketing email service. Start with free backend/email plans, monitor their quotas, and obtain approval before any paid hosting subscription. Resend quotas count authentication and admission emails together. Supabase Free may pause inactive projects and does not include automatic backups; export before launch and after material activity.

## Portability
Postgres schema and Supabase Edge Function are independent of hosting. The UI uses React with Next-compatible routes. The Sites preview build uses Vinext/Workers. GoDaddy needs a separately validated Node.js build/start adapter before upload; do not deploy the Worker start command to Node.js hosting.
