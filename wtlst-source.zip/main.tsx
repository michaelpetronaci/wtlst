import React from 'react';
import { createRoot } from 'react-dom/client';
import Wtlst from './components/wtlst';
import './app/globals.css';
createRoot(document.getElementById('root')!).render(<Wtlst/>);
