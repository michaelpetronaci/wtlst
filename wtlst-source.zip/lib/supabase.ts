import { createClient, type SupabaseClient } from '@supabase/supabase-js';
let client: SupabaseClient | null = null;
export async function getClient(): Promise<SupabaseClient | null> {
  if (client) return client;
  const response = await fetch('/api/config');
  if (!response.ok) throw new Error('Could not connect. Please try again.');
  const config = await response.json();
  if (!config.url || !config.key) return null;
  client = createClient(config.url, config.key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } });
  return client;
}
export async function rpc<T>(name: string, args: Record<string, unknown> = {}): Promise<T> {
  const db = await getClient();
  if (!db) throw new Error('Applications are not open yet. Please check back soon.');
  const { data, error } = await db.rpc(name, args);
  if (error) throw new Error(error.message);
  return data as T;
}
export async function deliverEmails() {
  const db = await getClient();
  if (!db) return;
  const { error } = await db.functions.invoke('send-emails', { body: {} });
  if (error) throw new Error('Your change is saved. Email delivery is pending and will be retried.');
}
